# Agent PHP

The sqreen PHP agent monitors your application against attacks, blocks them, and help you identify and solve security issues. 

Documentation https://docs.sqreen.io/sqreen-for-php/getting-started-in-php/
